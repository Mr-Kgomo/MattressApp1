/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class PrintProducts {
    private Product product;
    public PrintProducts(Product product) {
        this.product = product;
    }
    public void
            printTotalProductSales() {
                System.out.println("TOTAL PRODUCT SALES: " +
                product.GetTotalProductsSold());
            }
     public void
             printAverageProductSales() {
                 System.out.println("AVERAGE PRODUCT SALES: " +
                         product.GetAverageProductSold());
             }
    public void
         printMostPopularProduct() {
             System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
         }
    
}
