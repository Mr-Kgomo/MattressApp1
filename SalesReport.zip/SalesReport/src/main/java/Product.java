/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class Product implements IProduct {
    private String[] products;
    private int[][] sales;
    
    public Product(String[] products, int[][] sales){
        this.products = products;
        this.sales = sales;
    }
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; j++) {
            total += sales[i][j];
        }
    }
    return total;
    
}

@Override
public double
GetAverageProductSold() {
    int total = GetTotalProductsSold();
    int count = sales.length * sales[0].length; //3*3=9
    return (double) total / count; // 153/9 = 17.0
}
@Override
public String
        GetMostPopularProduct() {
            int maxTotal = -1;
            String popular = products[0];
            
            // check total per product
        for (int i = 0; i < sales.length; i++) {
            int rowTotal= 0;
            for (int j = 0; j < sales.length; j++) {
                rowTotal += sales[i][j];
            }
            if (rowTotal > maxTotal) {
                maxToatl = rowTotal;
                popular = products[i];
            }
        } 
        return popular + "(" + maxTotal + ")";
        }

