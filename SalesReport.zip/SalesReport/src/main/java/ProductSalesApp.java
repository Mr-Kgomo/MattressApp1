/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import java.util.Scanner;
public class ProductSalesApp {
    public static void main(String[] args){
        Scanner input = new
        Scanner(System.in);
        
        // 1D array(product names)
        String[] products = {"Cozy Nights", "Restonic Barbados", "Sealy Phuket"};
        
        // 2D array(3 products for 3 months)
        int[][] sales = new int[3][3];
        
        // input loop
        for (int i = 0; i< products.length; i++) {
            for (int j = 0; j < 3; j++){
                System.out.print("Enter number of sales for the month" + (j + 1)
                        + " for " + products[i] + " mattress: ");
                sales[i][j] = input.nextInt();
            }
            System.out.println();
            }
        int total = 0;
        int maxSale = sales[0][0];
        String popularProduct = products[0];
        
        // loop calculation
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
                
                if (sales [i][j] > maxSale) {
                    maxSale = sales[i][j];
                    popularProduct = products[i];
                }
                        
            }
        }
        // average = total/9
        int average = total / (products.length * 3);
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        
        System.out.println("\n****************************************");
        System.out.println("TOTAL PRODUCT SALES: " + total);
        System.out.println("AVERAGE PRODUCT SALES: " + average);
        System.out.println("MOST POPULAR PRODUCT: " + popularProduct + "(" + maxSale + ")");
        }
            
    }

